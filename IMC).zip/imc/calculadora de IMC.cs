﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Indice_de_Masa_Corporal
{
    public partial class Form1 : Form
    {
        static Op operaciones = new Op();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblRes.Text = operaciones.imc(double.Parse(txtPeso.Text), (double.Parse(txtAltura.Text))).ToString();
            if (double.Parse(lblRes.Text) < 18.5) ;
            {
                label5.Text = ("Neceitas comer mas para ganar peso.");
            }
            if (double.Parse(lblRes.Text) > 1 && double.Parse(lblRes.Text) < 24.9)
            {
                label5.Text = ("Tienes buen peso");
            }
            if (double.Parse(lblRes.Text) > 24.9 && double.Parse(lblRes.Text) < 29.9)
            {
                label5.Text = ("tienes sobrepeso");
            }
            if (double.Parse(lblRes.Text) > 29.9 && double.Parse(lblRes.Text) < 34.9)
            {
                label5.Text = ("tienes obesidad");
            }
            if (double.Parse(lblRes.Text) >= 35)
            {
                label5.Text = ("Tienes demasiado peso");
            }
        }    
        private void Form1_Load(object sender, EventArgs e)
        {

            }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
        }
    










